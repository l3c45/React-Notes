export const priority={
    low:"LOW",
    medium:"MEDIUM",
    high:"HIGH",
    critical:"CRITICAL"
}